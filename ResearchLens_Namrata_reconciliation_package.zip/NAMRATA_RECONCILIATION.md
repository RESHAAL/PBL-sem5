# ResearchLens AI — reconciliation of Namrata's five review points
Date: 2026-10-31

## Executive status
This reconciliation is based on the supplied project ZIP, the 100-row abstract-review CSV, the current provisional audit CSV, the dataset, and the saved embeddings. It does **not** claim human verification or a new latency run.

## 1. Precision@10 discrepancy — authoritative output
The currently supplied file `reshal_retrieval_results_audited_abstract_review_provisional.csv` has 100 rows (5 queries × 2 methods × 10 ranks). Recomputing macro Precision@10 directly from its `Relevant` column gives:
- BM25: **0.52**
- Semantic (MiniLM + FAISS): **0.38**

Formula: for each query, relevant rows in ranks 1–10 divided by 10; macro average across all five queries.

The currently supplied `reshal_aggregate_metrics_abstract_review_provisional.csv` also records 0.52 / 0.38. Thus **0.52 / 0.38 is authoritative for this specific current abstract-review CSV version only**, not a final verified study result.

Why other numbers differ:
- An earlier provisional aggregate artifact `reshal_aggregate_metrics_provisional.csv` records BM25 0.52 and Semantic 0.38 in this mounted workspace, while the earlier comparison artifact `reshal_previous_vs_current_provisional.csv` records Semantic 0.34. These are inconsistent artifact versions / label states.
- Namrata's stated 0.48 / 0.42 cannot be reproduced from the current 100-row CSV and is not present as a traceable output in the supplied current metric files. It may come from a different label sheet, filtering rule, or averaging calculation; the source file/version is needed to reconcile exactly.
- Therefore do not mix values across ZIP versions. Freeze the exact 100-row CSV and label version, then regenerate all metrics from it.

## 2. Human verification
Current labels are explicitly `Model-assisted abstract review; human confirmation required`. They are not independent human judgments. A human reviewer (ideally two reviewers with adjudication of disagreements) must inspect title + abstract and fill/confirm `Human_Relevance` in `pooled_judgment_candidates.csv`. The candidate pool is the deduplicated union of BM25 and semantic top-10 results for each query (77 unique query-paper pairs total). Until this is done, all metrics remain provisional.

## 3. nDCG@10 and IDCG protocol
The existing provisional script computes IDCG by sorting the labels from each method's own retrieved top-10. This is **retrieved-set nDCG**, not corpus-wide ideal ranking.

Recommended practical protocol:
- Build a judged pool per query from the union of both systems' top-10 results (pooling), deduplicated by Paper_ID.
- Human judge every item in that pool.
- For each method's nDCG@10, compute DCG from that method's ranked top-10, and IDCG from the top 10 relevance grades after sorting **all judged documents in the shared per-query pool**.
- State clearly that this is pooled nDCG; it is not corpus-wide nDCG because documents outside the pool are unjudged.
- If the pool has no relevant document, IDCG=0 and nDCG=NA. Do not silently convert NA to zero.

The file `recompute_metrics_human_judged_pool.py` implements this protocol after human labels are completed.

## 4. Corpus-wide relevant-document counts, Recall@10, F1@10
Verified corpus size is 2,200 records, with 220 records in each of the ten domains; each approved query is restricted to its matching domain, so its search universe is 220 documents.

**Corpus-wide relevant counts are not currently available.** They cannot be inferred from the top-10 labels or similarity scores. To claim true corpus-wide Recall@10 and F1@10, a reviewer must judge all 220 documents in each query's domain (1,100 query-document judgments total), or use a clearly named pooled protocol.

The included `pooled_judgment_candidates.csv` contains 77 unique query-paper pairs (14–18 per query) from the union of both systems' top-10 results. After human review it supports **pooled Recall@10 / pooled F1@10**, not corpus-wide recall. Formula:
- pooled Recall@10 = relevant retrieved in method top-10 / relevant documents in the shared judged pool.
- F1@10 = 2 × P@10 × pooled Recall@10 / (P@10 + pooled Recall@10).
If there are zero relevant documents in the pool, recall/F1 are NA and should be reported as undefined.

## 5. Latency
No new timing values were fabricated. The project's prior benchmark script uses different generic queries and regenerates embeddings/indexes; it is not the exact five-query experiment timing requested. Also, the current runtime used for this audit does not have `faiss`, `rank_bm25`, or `sentence_transformers` installed, so an actual rerun could not be performed here.

Included `benchmark_latency_reconciled.py` is ready to run from the project root. It uses the exact five approved queries, the same 220-document domain subsets, 3 warm-ups and 30 repeats. It reports:
- BM25 search-only: query pre-tokenized; BM25 scoring only.
- BM25 end-to-end query: tokenization + BM25 scoring.
- FAISS search-only: `index.search` with precomputed query vector.
- Semantic end-to-end query: query embedding + FAISS search.
Offline corpus/model/index loading and index construction are excluded from per-query timing for both systems. Report mean, median, standard deviation, min and max. Run on the same machine and environment for both methods.

## Verified facts from project files
- Dataset: 2,200 rows, 2,200 unique Paper_ID values.
- Each of the ten domains contains 220 papers.
- The approved query script includes the exact five approved queries; the fifth is `AI for climate prediction`.
- Saved embedding file is present and the retrieval script checks Paper_ID ordering before running.
- The current result file has 100 rows.
- Relevance labels remain provisional; no independent human adjudication is evidenced.

## Files in this reconciliation package
- `reconciled_per_query_metrics_provisional.csv`: fresh metrics from current audit CSV.
- `reconciled_aggregate_metrics_provisional.csv`: macro metrics from current audit CSV.
- `corpus_domain_counts.csv`: actual domain universe sizes.
- `pooled_judgment_candidates.csv`: 77 unique query-paper pairs to be human judged.
- `recompute_metrics_human_judged_pool.py`: pooled nDCG / pooled Recall / F1 script; run after filling Human_Relevance.
- `benchmark_latency_reconciled.py`: exact-query comparable latency benchmark; run locally from project root.
- `NAMRATA_RECONCILIATION.md`: this document.

## Decision for paper
Do not yet update the paper with final retrieval metrics, corpus-wide recall/F1, or new latency values. Current 0.52 / 0.38 are reproducible only as provisional macro Precision@10 from the current model-assisted label file. Human labels, shared judged-pool nDCG/recall, and local latency rerun are still required.
