"""
Final metrics from human-judged pooled candidates.
Input:
  pooled_judgment_candidates.csv with Human_Relevance (0/1) filled by reviewer.
  reshal_retrieval_results_audited_abstract_review_provisional.csv (ranked top-10s).
Protocol:
- Candidate pool = union of BM25 top-10 and Semantic top-10 per query (deduplicated by Paper_ID).
- nDCG ideal ranking is over all judged candidates in that query's pool, not only a method's retrieved top-10.
- Recall is explicitly pooled recall: relevant retrieved in method top-10 / all relevant in the pooled union.
- This is NOT corpus-wide recall unless all 220 papers in that query's domain are judged.
"""
import sys
import numpy as np
import pandas as pd
from pathlib import Path
RANKED=Path(sys.argv[1] if len(sys.argv)>1 else 'reshal_retrieval_results_audited_abstract_review_provisional.csv')
POOL=Path(sys.argv[2] if len(sys.argv)>2 else 'pooled_judgment_candidates.csv')
ranked=pd.read_csv(RANKED); pool=pd.read_csv(POOL)
if pool.Human_Relevance.isna().any() or not set(pd.to_numeric(pool.Human_Relevance).unique()).issubset({0,1}):
 raise SystemExit('Fill Human_Relevance with human judgments 0/1 for every pool row first.')
pool['Human_Relevance']=pd.to_numeric(pool.Human_Relevance).astype(int)
pool_map={(r.Query,str(r.Paper_ID)):int(r.Human_Relevance) for r in pool.itertuples()}
out=[]
for (q,domain,method),g in ranked.groupby(['Query','Domain','Method'],sort=False):
 g=g.sort_values('Rank')
 rel=np.array([pool_map[(q,str(pid))] for pid in g.Paper_ID],dtype=int)
 discounts=1/np.log2(np.arange(2,len(rel)+2))
 dcg=float(np.sum((2**rel-1)*discounts))
 pool_rel=pool.loc[pool.Query.eq(q),'Human_Relevance'].to_numpy(dtype=int)
 ideal=np.sort(pool_rel)[::-1][:10]
 idcg=float(np.sum((2**ideal-1)*discounts[:len(ideal)]))
 total=int(pool_rel.sum()); retrieved=int(rel.sum())
 p=retrieved/10; recall=retrieved/total if total else np.nan
 f1=(2*p*recall/(p+recall)) if total and (p+recall)>0 else (0.0 if total else np.nan)
 out.append({'Query':q,'Domain':domain,'Method':method,'Relevant_in_top10':retrieved,
 'Pooled_relevant_documents':total,'Precision@10':p,'Pooled_Recall@10':recall,'Pooled_F1@10':f1,
 'DCG@10':dcg,'IDCG@10_pool_ideal':idcg,'nDCG@10_pool_ideal':dcg/idcg if idcg else np.nan,
 'Recall_scope':'pooled union of both methods top-10; not corpus-wide'})
res=pd.DataFrame(out); res.to_csv('human_judged_pooled_metrics.csv',index=False)
print(res.to_string(index=False))
