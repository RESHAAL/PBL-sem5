import pandas as pd, numpy as np
import sys
source=sys.argv[1] if len(sys.argv)>1 else "reshal_retrieval_results_audited_abstract_review_provisional.csv"
df=pd.read_csv(source)
label="Relevant" if "Relevant" in df.columns else "Audited_Relevant"
rows=[]
for (q,domain,method),g in df.groupby(["Query","Domain","Method"],sort=False):
    g=g.sort_values("Rank")
    rel=g[label].astype(int).to_numpy()
    discounts=1/np.log2(np.arange(2,len(rel)+2))
    dcg=((2**rel-1)*discounts).sum()
    idcg=((2**np.sort(rel)[::-1]-1)*discounts).sum()
    rows.append({"Query":q,"Domain":domain,"Method":method,"Results":len(g),"Relevant_in_top10":int(rel.sum()),"Precision@10":rel.sum()/10,"DCG@10":dcg,"IDCG@10":idcg,"nDCG@10":dcg/idcg if idcg else np.nan})
out=pd.DataFrame(rows)
out.to_csv("reshal_per_query_metrics_recomputed.csv",index=False)
print(out.to_string(index=False))
print("\nMacro metrics:")
print(out.groupby("Method").agg(Macro_Precision_at_10=("Precision@10","mean"),Macro_nDCG_defined_queries_only=("nDCG@10","mean"),Defined_nDCG_queries=("nDCG@10","count")).to_string())
