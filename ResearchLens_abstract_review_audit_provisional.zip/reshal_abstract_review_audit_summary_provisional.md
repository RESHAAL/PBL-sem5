# ResearchLens AI — abstract-review audit (provisional)

## Scope and integrity
- Approved query set: five exact queries, including `AI for climate prediction`.
- 100 retrieved rows: 5 queries × 2 methods × 10 ranks.
- The supplied CSV's 100 rows were joined to the existing abstract-review working audit by Query, Method, Rank, and Paper_ID; all 100 keys matched exactly.
- This is a model-assisted review of the supplied titles and abstracts, not an independent human adjudication. Human confirmation remains required before calling labels final.

## Relevance criteria
- **AI for early disease detection:** Relevant if the abstract connects AI/ML to early disease detection, screening, prediction, early warning, or diagnosis; generic healthcare AI without this connection is not relevant.
- **Machine learning for crop disease prediction:** Relevant if AI/ML is applied to plant/crop disease detection, classification, diagnosis, or prediction. General agriculture, yield prediction, or data management alone is not relevant.
- **Explainable AI for cybersecurity:** Strict conjunction: explainability/XAI must be substantively connected to a cybersecurity or computer-security task. Generic XAI or cybersecurity without explainability is not relevant.
- **AI-based personalized learning:** Relevant if AI is used for personalized, individualized, or adaptive learning/instruction. General AI-in-education without a clear personalization/adaptation link is not relevant.
- **AI for climate prediction:** Relevant if AI is used to forecast climate variables, climate change, weather/climate events, or related climate patterns. Pollution, emissions, environmental monitoring, or environmental sustainability alone is not sufficient.

## Metrics
- Precision@10 = relevant items in ranks 1–10 divided by 10.
- Binary-gain nDCG@10: DCG = Σ((2^relᵢ − 1)/log₂(i+1)); IDCG uses the same labels sorted with all relevant items first.
- If IDCG@10 = 0, nDCG@10 is reported as `NA` (not zero); Precision@10 remains 0.
- Aggregate Precision@10 is the unweighted macro mean across all five queries. Aggregate nDCG@10 is the macro mean over queries with defined nDCG; NA cases and counts are shown separately.

## Limitations
- Labels are model-assisted and require human review, especially borderline broad reviews and the cybersecurity query's strict conjunction.
- Relevance is judged only from the title and abstract supplied in the CSV; full texts were not independently checked.
- The paper's prior metrics reportedly used three queries, while this rerun uses the approved five-query set; therefore differences are not an apples-to-apples comparison.
- The climate query was retained exactly as `AI for climate prediction`; it was not replaced by `Deep learning for climate prediction`.

## Files
- `reshal_retrieval_results_audited_abstract_review_provisional.csv`
- `reshal_per_query_metrics_abstract_review_provisional.csv`
- `reshal_aggregate_metrics_abstract_review_provisional.csv`
- `reshal_previous_vs_abstract_review_provisional.csv`
- `recompute_metrics_abstract_review.py`
