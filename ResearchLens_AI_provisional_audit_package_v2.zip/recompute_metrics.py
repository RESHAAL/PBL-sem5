import sys, math
import pandas as pd

path = sys.argv[1] if len(sys.argv) > 1 else "reshal_retrieval_results_audited_provisional.csv"
df = pd.read_csv(path)
required = {"Query", "Method", "Rank", "Relevant"}
missing = required - set(df.columns)
if missing: raise ValueError(f"Missing required columns: {sorted(missing)}")
df["Relevant"] = pd.to_numeric(df["Relevant"], errors="raise").astype(int)
rows=[]
for (query, method), group in df.groupby(["Query", "Method"], sort=False):
    group=group.sort_values("Rank")
    rel=group["Relevant"].tolist()[:10]
    p=sum(rel)/10
    dcg=sum((2**r-1)/math.log2(i+2) for i,r in enumerate(rel))
    ideal=sorted(rel, reverse=True)
    idcg=sum((2**r-1)/math.log2(i+2) for i,r in enumerate(ideal))
    rows.append({"Query":query,"Method":method,"N_results":len(rel),"Relevant_in_top10":sum(rel),"Precision_at_10":p,"DCG_at_10":dcg,"IDCG_at_10":idcg,"nDCG_at_10":dcg/idcg if idcg else float("nan"),"nDCG_status":"defined" if idcg else "NA: IDCG=0"})
metrics=pd.DataFrame(rows)
metrics.to_csv("reshal_per_query_metrics_recomputed.csv", index=False)
agg=[]
for method, g in metrics.groupby("Method", sort=False):
    valid=g["nDCG_at_10"].notna()
    agg.append({"Method":method,"Queries":len(g),"Macro_Precision_at_10":g["Precision_at_10"].mean(),"Macro_nDCG_at_10_valid_queries_only":g.loc[valid,"nDCG_at_10"].mean(),"Queries_with_defined_nDCG":int(valid.sum()),"Queries_with_NA_nDCG":int((~valid).sum())})
pd.DataFrame(agg).to_csv("reshal_aggregate_metrics_recomputed.csv",index=False)
print(metrics.to_string(index=False))
print("\nAGGREGATE\n", pd.DataFrame(agg).to_string(index=False))
