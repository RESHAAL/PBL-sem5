# ResearchLens AI — Retrieval relevance audit (PROVISIONAL)

## Status and limitations
This audit labels the 100 supplied retrieval rows using their titles and abstracts and the explicit criteria below. Labels are **model-assisted and provisional**, not independently human-verified. A project team member should review each title/abstract, especially borderline cases, before these values are described as final.

## Dataset integrity
The user-run consistency check reported 100 result rows, 0 missing Paper IDs, 0 abstract mismatches, and 0 domain mismatches against `data/research_papers_real.csv`.

## Query criteria

### AI for early disease detection
Relevant if AI/ML is tied to early disease detection, prediction, screening, or diagnosis; broad healthcare papers count only when the abstract explicitly discusses early detection/diagnosis. Generic healthcare AI alone is not enough.

### Machine learning for crop disease prediction
Relevant if AI/ML addresses crop/plant disease detection, classification, prediction, or early warning. General crop yield, precision agriculture, data management, or pest management alone is not enough.

### Explainable AI for cybersecurity
Relevant only if explainable AI/XAI is substantively connected to a cybersecurity task or cyberattack/security threat. Generic XAI alone or cybersecurity AI without explainability is not enough.

### AI-based personalized learning
Relevant if AI is linked to personalized/adaptive learning or tailoring instruction/content/pacing to learner needs. General AI-in-education alone is not enough.

### AI for climate prediction
Relevant if AI/ML is used to predict/forecast climate, weather, climate variables, or climate-related events. Pollution, water quality, carbon-emissions prediction, or climate-change discussion alone is not enough.

## Metric definitions
- Precision@10 = relevant items in ranks 1–10 divided by 10.
- Binary-gain nDCG@10 uses DCG = sum((2^rel_i - 1) / log2(i+1)) with ranks i starting at 1, normalized by ideal DCG.
- If IDCG@10 = 0, nDCG@10 is reported as NA; Precision@10 remains 0.
- Aggregate Precision@10 is an unweighted macro-average across all five queries. Aggregate nDCG@10 is the macro-average over queries with defined nDCG; the count of excluded NA queries is reported.

## Important comparison caveat
Previously reported paper values (BM25 Precision@10 0.44 / mean nDCG 0.896; semantic Precision@10 0.36 / nDCG 0.854) were reportedly based on three queries, while this run uses five approved queries and provisional labels. They are not directly comparable until query scope, relevance judgments, and nDCG aggregation are aligned.

## Files
- `reshal_retrieval_results_audited_provisional.csv`: rows, abstracts, labels, and audit notes.
- `reshal_per_query_metrics_provisional.csv`: per-query metrics.
- `reshal_aggregate_metrics_provisional.csv`: macro aggregates.
- `recompute_metrics.py`: reproducible metric computation using the `Relevant` column.

## Manual review checklist
1. Confirm every label against the full abstract and the query criterion.
2. Change `Relevant` to 0 or 1 where needed and record the reason in `Audit_Notes`.
3. Run `python recompute_metrics.py reshal_retrieval_results_audited_provisional.csv` after adapting/using the script.
4. Replace provisional filenames/status only after human review is complete.
