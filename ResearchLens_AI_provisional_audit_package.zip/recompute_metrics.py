"""
Reproduce Precision@10 and nDCG@10 from the audited retrieval CSV.
Input: reshal_retrieval_results_audited_provisional.csv
The Relevant labels are provisional/model-assisted and require human confirmation.
nDCG@10 is NA when IDCG@10 == 0 (no relevant result in the judged top 10).
"""
import math
import pandas as pd

INPUT = "reshal_retrieval_results_audited_provisional.csv"
OUT_QUERY = "reshal_per_query_metrics_recomputed.csv"
OUT_AGG = "reshal_aggregate_metrics_recomputed.csv"

df = pd.read_csv(INPUT)
required = {"Query", "Domain", "Method", "Rank", "Relevant"}
missing = required - set(df.columns)
if missing:
    raise ValueError(f"Missing columns: {sorted(missing)}")
if df["Relevant"].isna().any():
    raise ValueError("Relevant labels contain blanks; label all judged rows before computing metrics.")
df["Relevant"] = df["Relevant"].astype(int)
if not set(df["Relevant"].unique()).issubset({0, 1}):
    raise ValueError("Relevant must contain only binary labels 0 or 1.")

def dcg(rels):
    return sum((2 ** int(rel) - 1) / math.log2(i + 2) for i, rel in enumerate(rels))

rows = []
for (query, method), group in df.groupby(["Query", "Method"], sort=False):
    group = group.sort_values("Rank")
    rels = group["Relevant"].tolist()[:10]
    if len(rels) != 10:
        raise ValueError(f"{query} / {method} has {len(rels)} results, expected 10.")
    p10 = sum(rels) / 10
    idcg = dcg(sorted(rels, reverse=True))
    ndcg = dcg(rels) / idcg if idcg > 0 else float("nan")
    rows.append({
        "Query": query, "Domain": group["Domain"].iloc[0], "Method": method,
        "K": 10, "Relevant_in_top10": sum(rels), "Precision@10": p10,
        "nDCG@10": ndcg, "IDCG@10": idcg,
        "nDCG_status": "OK" if idcg > 0 else "NA — IDCG@10=0"
    })
per_query = pd.DataFrame(rows)
per_query.to_csv(OUT_QUERY, index=False)

agg_rows = []
for method, group in per_query.groupby("Method", sort=False):
    valid = group["nDCG@10"].dropna()
    agg_rows.append({
        "Method": method, "Queries": len(group),
        "Macro_Precision@10": group["Precision@10"].mean(),
        "Macro_nDCG@10_excluding_NA": valid.mean() if len(valid) else float("nan"),
        "Queries_in_nDCG_mean": len(valid),
        "Queries_nDCG_NA": int(group["nDCG@10"].isna().sum())
    })
pd.DataFrame(agg_rows).to_csv(OUT_AGG, index=False)
print(per_query.to_string(index=False))
print("\\nAggregate metrics:\\n", pd.DataFrame(agg_rows).to_string(index=False))
print(f"Saved {OUT_QUERY} and {OUT_AGG}")
