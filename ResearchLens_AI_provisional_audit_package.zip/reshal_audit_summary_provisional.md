# ResearchLens AI retrieval experiment — provisional audit package

## Status and scope
- Exact approved queries retained: AI for early disease detection (Healthcare); Machine learning for crop disease prediction (Agriculture); Explainable AI for cybersecurity (Computer Science); AI-based personalized learning (Education); AI for climate prediction (Environmental Science).
- 5 queries × 2 methods × 10 ranked results = 100 rows.
- Retrieval CSV retains Paper_ID, title, abstract, rank, score, query, domain, method.
- Relevance labels in this package are **model-assisted provisional judgments based on the available titles and abstracts**, not independent human labels. A human reviewer should confirm/correct them before they are presented as final verified metrics.

## Relevance criteria used
Binary relevance (1/0) assessed against the specific query task, using both title and abstract:
1. Healthcare: AI/ML must be connected to early disease detection, prediction, or diagnosis; generic healthcare AI without a clear early-detection connection is non-relevant.
2. Agriculture: AI/ML must be connected to crop/plant disease detection or prediction. General yield prediction or agricultural data management alone is non-relevant; broad agriculture reviews mentioning disease detection are provisionally relevant.
3. Cybersecurity: strict conjunctive criterion — the abstract must connect explainable AI/XAI to a cybersecurity task. Generic XAI foundations alone, or cyber-attack detection with no explainability component, are non-relevant.
4. Education: AI must be connected to personalized/adaptive learning. General AI in education without a clear personalization link is non-relevant.
5. Climate: AI must be connected to forecasting climate-related variables/events. General emissions, environmental impact, pollution or water-quality prediction is not automatically climate prediction. The air-pollution forecasting review is provisionally relevant because its abstract also discusses climate/heat-wave prediction.

## Metric method
- Precision@10 = number of relevant items among the top 10 divided by 10.
- Binary-gain nDCG@10: DCG = sum((2^rel_i - 1)/log2(i+1)), with rank positions i starting at 1; nDCG = DCG / IDCG.
- If IDCG@10 = 0 (no relevant items in the judged top 10), nDCG@10 is reported as NA, not zero. Precision@10 remains 0.
- Aggregate Precision@10 is the unweighted macro mean across the five queries per method. Aggregate nDCG@10 is the macro mean over queries where IDCG > 0; NA cases are excluded and counted separately.

## Current provisional aggregates
                              Scope                    Method  Queries  Macro_Precision@10  Macro_nDCG@10_excluding_NA  Queries_in_nDCG_mean  Queries_nDCG_NA                         Interpretation
Aggregate across 5 approved queries                      BM25        5                0.52                    0.975161                     4                1 Provisional labels; not human-verified
Aggregate across 5 approved queries Semantic (MiniLM + FAISS)        5                0.34                    0.888736                     4                1 Provisional labels; not human-verified

## Previous-paper comparison
Historical paper-reported values supplied in the project notes: BM25 Precision@10 0.44, nDCG@10 0.896; semantic Precision@10 0.36, nDCG@10 0.854. This run is not directly comparable yet because it uses the approved five-query set while the prior values were reportedly calculated on three queries, and current relevance judgments are provisional. See `reshal_previous_vs_current_provisional.csv`. Do not call these final verified discrepancies until labels and query scope are reconciled.

## Limitations / audit notes
- Judgments are provisional and should be independently checked by a human reviewer.
- Abstracts are the available evidence; full-text papers were not independently reviewed.
- Duplicate or near-duplicate records may appear in ranked results; they are retained as returned by the retrieval system.
- Reproducibility depends on the same input dataset, saved embeddings, model version, tokenization and retrieval code.
- This package does not claim that files have been sent to a project group.
